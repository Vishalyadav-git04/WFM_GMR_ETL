from typing import List, Dict, Any, Optional
from domain.interfaces import IOMRepository
from domain.entities import OMOpenAgeingEntity

class OMUseCase:
    def __init__(self, om_repo: IOMRepository):
        self.om_repo = om_repo

    def get_productivity_team(self, filters: Dict[str, Any], limit: int, offset: int) -> List[Any]:
        return self.om_repo.get_productivity_team(filters, limit, offset)

    def get_productivity_trend(self, filters: Dict[str, Any], limit: int, offset: int) -> List[Any]:
        return self.om_repo.get_productivity_trend(filters, limit, offset)

    def get_open_ageing(self, filters: Dict[str, Any], limit: int, offset: int) -> List[Any]:
        return self.om_repo.get_open_ageing(filters, limit, offset)

    def get_avg_closure_time(self, filters: Dict[str, Any], limit: int, offset: int) -> List[Any]:
        return self.om_repo.get_avg_closure_time(filters, limit, offset)

    def get_closed_analysis(self, filters: Dict[str, Any], limit: int, offset: int) -> List[Any]:
        return self.om_repo.get_closed_analysis(filters, limit, offset)
